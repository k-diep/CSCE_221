#include "DoubleHashTable.h"

///////////////////// TODO: FILL OUT THE FUNCTIONS /////////////////////

// constructor (NOTE: graders will use a default constructor for testing)
DoubleHashTable::DoubleHashTable() {
	
}

// destructor
DoubleHashTable::~DoubleHashTable() {

}

// inserts the given string key
void DoubleHashTable::insert(std::string key, int val) {

}

// removes the given key from the hash table - if the key is not in the list, throw an error
int DoubleHashTable::remove(std::string key) {

	return 0;
}

// getter to obtain the value associated with the given key
int DoubleHashTable::get(std::string key) {

	return 0;
}

// prints number of occurrances for all given strings to a txt file
void DoubleHashTable::printAll(std::string filename) {

}

// helper functions 
int DoubleHashTable::secondHash(std::string s) {
	
	return 0;
}
