/*
 * hash.h
 *
 *  Created on: Dec 1, 2019
 *      Author: Khoa
 */
#include <string>

#ifndef HASH_H_
#define HASH_H_

struct node{
	std::string key = "";
	int val = 0;
};



#endif /* HASH_H_ */
